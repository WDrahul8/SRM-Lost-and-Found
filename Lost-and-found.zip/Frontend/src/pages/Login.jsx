import React, { useState } from "react";
import Navbar from "../components/Navbar";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useSnackbar } from "notistack";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const { enqueueSnackbar } = useSnackbar();
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
      const res = await axios.post("http://localhost:3000/login", {
        username,
        password,
      });

      if (res.status === 200) {
        localStorage.setItem("role", res.data.role);
        localStorage.setItem("username", username);
        enqueueSnackbar("Login successful!", { variant: "success" });
        navigate("/");
      }
    } catch (err) {
      enqueueSnackbar("Invalid credentials!", { variant: "error" });
    }
  };

  return (
    <>
      <Navbar />
      <div style={{
        backgroundColor: "#f9f9f9",
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }}>
        <div style={{
          maxWidth: "400px",
          padding: "20px",
          border: "1px solid #ccc",
          borderRadius: "8px",
          backgroundColor: "#fff"
        }}>
          <h2 style={{ textAlign: "center" }}>Login</h2>
          <form onSubmit={handleLogin}>
            <input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
              style={{ width: "100%", padding: "10px", margin: "10px 0" }}
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              style={{ width: "100%", padding: "10px", margin: "10px 0" }}
            />
            <button type="submit" style={{
              width: "100%",
              padding: "10px",
              backgroundColor: "#007bff",
              color: "white",
              border: "none",
              borderRadius: "5px"
            }}>
              Login
            </button>
          </form>
        </div>
      </div>
    </>
  );
}

export default Login;

import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import logo from "../assets/logo.png";

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [role, setRole] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    const storedRole = localStorage.getItem("role");
    setRole(storedRole);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("role");
    localStorage.removeItem("username");
    setRole(null);
    navigate("/login");
  };

  return (
    <nav className="navbar">
      <Link to="/"><img src={logo} alt="logo" className="logo" /></Link>
      <ul className={menuOpen ? "active" : "inactive"}>
        <li><Link to="/">Home</Link></li>
        <li><Link to="/find">Find Item</Link></li>
        <li><Link to="/post">Post Item</Link></li>
        <li><a href="/#about">About Us</a></li>
        {role ? (
          <li><button onClick={handleLogout} className="logout-btn">Logout</button></li>
        ) : (
          <>
            <li><Link to="/login">Login</Link></li>
            <li><Link to="/register">Register</Link></li>
          </>
        )}
      </ul>
      <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)}>
        ☰
      </button>
    </nav>
  );
}

export default Navbar;
import React from "react";

function Login() {
  return (
    <div style={{ padding: "2rem", textAlign: "center", color: "#fff" }}>
      <h2>Login Page</h2>
      <p>Login form will go here.</p>
    </div>
  );
}

export default Login;

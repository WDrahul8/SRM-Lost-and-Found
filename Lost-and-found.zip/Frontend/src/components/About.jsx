function About() {
  return (
    <section
      id="about"
      style={{
        backgroundColor: '#f9f9f9',
        padding: '40px',
        fontFamily: 'Segoe UI, sans-serif',
      }}
    >
      <h1
        style={{
          fontSize: '2.5rem',
          fontWeight: 'bold',
          color: '#007bff',
          textAlign: 'center',
          marginBottom: '30px',
        }}
      >
        About Us
      </h1>

      <div
        style={{
          maxWidth: '900px',
          margin: '0 auto',
          textAlign: 'justify',
          lineHeight: '1.8',
          fontSize: '1.1rem',
          color: '#333',
        }}
      >
        <p style={{ marginBottom: '20px' }}>
          At <strong>SRM Lost and Found</strong>, we are committed to supporting the students, staff, and faculty of
          <strong> SRM Institute of Science and Technology – Trichy Campus</strong> by providing a reliable and centralized
          platform for recovering lost items and reporting found possessions.
        </p>

        <p style={{ marginBottom: '20px' }}>
          Losing a personal item—be it a wallet, ID card, laptop, or even a cherished memento—can be distressing.
          We understand how important these belongings can be, especially in a busy academic environment. That’s
          why we created this digital solution—to make it easier for everyone on campus to search, report, and
          retrieve lost items quickly and efficiently.
        </p>

        <p style={{ marginBottom: '20px' }}>
          This platform is not just a tool; it’s a <strong>community-driven initiative built by students, for students</strong>.
          It empowers individuals to post about missing items they’ve lost or found within the campus. Whether the
          object is valuable in terms of cost or sentiment, our goal is to reunite it with its rightful owner.
        </p>

        <p style={{ marginBottom: '20px' }}>
          Through this system, we aim to foster a spirit of collaboration, trust, and empathy among the SRM Trichy family.
          Every report submitted, every item returned, strengthens our sense of community and responsibility. Let’s work
          together to make our campus a more connected and caring place.
        </p>
      </div>

      <footer
        style={{
          marginTop: '40px',
          textAlign: 'center',
          color: '#777',
          fontSize: '0.9rem',
        }}
      >
        <p>&copy; 2025 SRM Lost and Found</p>
        <p>
          Designed and Built by Students of 3rd CSE B —{' '}
          <strong>Rahul, Asvin Ram, Udit Avinash</strong>
        </p>
      </footer>
    </section>
  );
}

export default About;

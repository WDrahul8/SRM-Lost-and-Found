import express, { request } from "express";
import { PORT, mongoURL } from "./config.js";
import mongoose from "mongoose";
import { Item } from "./models/itemmodel.js";
import cors from "cors";
import { createRequire } from "module";
const require = createRequire(import.meta.url);

const app = express();
app.use(express.json());
app.use(cors());
app.use("/files", express.static("files"));

// ================================= multer ==================================
const multer = require("multer");

const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "./files");
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now();
    cb(null, uniqueSuffix + file.originalname);
  },
});

const upload = multer({ storage: storage });

// ============================ Items CRUD Routes ============================

// Get all items
app.get("/item", async (req, res) => {
  try {
    const items = await Item.find({});
    return res.status(200).json({
      count: items.length,
      data: items,
    });
  } catch (error) {
    res.status(500).send({ message: error.message });
  }
});

// Create new item with image upload
app.post("/item", upload.single("file"), async (req, res) => {
  try {
    if (
      !req.body.name ||
      !req.body.email ||
      !req.body.phoneno ||
      !req.body.title ||
      !req.body.description
    ) {
      return res.status(400).send({ message: "All fields are required" });
    }

    const newItem = {
      name: req.body.name,
      email: req.body.email,
      phoneno: req.body.phoneno,
      title: req.body.title,
      description: req.body.description,
      image: req.file.filename,
    };

    const item = await Item.create(newItem);
    return res.status(200).send(item);
  } catch (error) {
    console.log(error);
    res.status(500).send("Error while saving item");
  }
});

// Get item by ID
app.get("/item/:id", async (req, res) => {
  try {
    const item = await Item.findById(req.params.id);
    return res.status(200).json(item);
  } catch (error) {
    res.status(500).send({ message: error.message });
  }
});

// Delete item by ID
app.delete("/item/:id", async (req, res) => {
  try {
    const item = await Item.findByIdAndDelete(req.params.id);
    if (!item) {
      return res.status(404).json({ message: "Item not found" });
    }
    return res.status(200).json({ message: "Item deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// =============================== Auth Routes ===============================

const users = [];

// Register a user (dev mode: allow re-register)
app.post("/register", (req, res) => {
  const { username, password, role } = req.body;
  const exists = users.find((u) => u.username === username);
  if (exists) {
    return res.status(200).json({ message: "Already registered", role: exists.role });
  }
  users.push({ username, password, role });
  res.status(201).json({ message: "Registered successfully" });
});

// Login a user
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  const user = users.find((u) => u.username === username && u.password === password);
  if (user) {
    res.status(200).json({ role: user.role });
  } else {
    res.status(401).json({ message: "Invalid credentials" });
  }
});

// ============================== Server & DB ==============================

app.listen(PORT, () => {
  console.log(`✅ Server started at http://localhost:${PORT}`);
});

mongoose
  .connect(mongoURL)
  .then(() => {
    console.log("✅ Connected to MongoDB");
  })
  .catch((error) => {
    console.log("❌ MongoDB Connection Error:", error);
  });

import { useState, useEffect } from "react";
import { api } from "../config";
import noImage from "../assets/no-image.png";
import axios from "axios";

export default function Itemcard(props) {
  const [image, setImage] = useState(noImage);

  useEffect(() => {
    axios
      .get(`${api}/files/${props.image}`)
      .then(() => {
        setImage(`${api}/files/${props.image}`);
      })
      .catch(() => {
        setImage(noImage);
      });
  }, [props.image]);

  const handleDelete = async () => {
    try {
      await axios.delete(`${api}/item/${props.id}`);
      window.location.reload();
    } catch (err) {
      console.error("Delete failed:", err);
    }
  };

  return (
    <div data-aos="fade-up" className="card">
      <div
        style={{ cursor: "pointer" }}
        onClick={() => window.location.href = "/find/details/" + props.id}
      >
        <div className="card-img">
          <img src={image} alt="" />
        </div>
        <div className="card-desc">
          <h2>{props.title}</h2>
          <p>{props.description}</p>
        </div>
      </div>

      <button
        onClick={handleDelete}
        style={{
          marginTop: '10px',
          backgroundColor: '#ff4d4f',
          color: 'white',
          border: 'none',
          padding: '8px 12px',
          cursor: 'pointer',
          borderRadius: '5px'
        }}
      >
        Delete
      </button>
    </div>
  );
}
